local wzrdroot,wzrd1337,wzrd777='/data/user/0/com.sandboxol.blockymods/app_resources/','',''
local function wzrd1488(path,content)
local wzrd=io.open(path,'w')
if wzrd then 
wzrd:write(content)
wzrd:close()
end 
end 
local lfs=require('lfs')
lfs.mkdir(wzrdroot..'Media')
lfs.mkdir(wzrdroot..'Media/Scripts')
lfs.mkdir(wzrdroot..'Media/Scripts/Game')
lfs.mkdir(wzrdroot..'Media/Scripts/Game/g1100')
lfs.mkdir(wzrdroot..'Media/Scripts/Game/g1100/setting')
lfs.mkdir(wzrdroot..'Media/Setting')
for i=1,2700 do if (i==253) or (i>=700 and i<=714) or (i>=752 and i<=899) or (i>=422 and i<=444) or (i==446) or (i==451) or (i==462) or (i==464) or (i>=506 and i<=531) or (i==346) or (i==276) or (i>=310 and i<=313) or (i>=2301 and i<=2307) or (i>=2001 and i<=2002) or (i==2337) or (i>=1236 and i<=1257) then wzrd1337=wzrd1337..'\n'..i..'	0'elseif (i>=1 and i<=160) or (i==162) or (i==165) or(i>=168 and i<=174)  or (i>=2417 and i<=2428) or (i>=2400 and i<=2415) or (i>=2431 and i<=2437) or (i>=2308 and i<=2312) or (i==408) or (i==335) or (i==482) then wzrd777=wzrd777..'\n'..i..'	0' end end 

wzrd1488(wzrdroot..'Media/Scripts/Game/g1100/setting/CreativeItem.csv','ItemId	subItemId'..wzrd1337)wzrd1488(wzrdroot..'Media/Scripts/Game/g1100/setting/CreativeBlock.csv','ItemId	subItemId'..wzrd777)
wzrd1488(wzrdroot..'Media/Setting/words.txt','lashara pashla naxuy')
local wzrd=io.open('/storage/emulated/0/Android/data/com.sandboxol.blockymods/files/Download/SandboxOL/BlockManv2/map_temp/g20151633/ModByWizard.zip','r')
if wzrd then 
local wzrd2=wzrd:read('*a')
wzrd:close()
wzrd1488(wzrdroot..'common.zip',wzrd2)
wzrd,wzrd2=nil,nil end